int main()
{
#ifndef A
}
#endif
