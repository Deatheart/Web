#include "caut.h"
//primitive type
int a;
long a1;
char a2;
//complex type
typedef struct d{
 int d1;
 char d2;
}dd;

struct A{
  char test;
  unsigned int tt;
  dd* ddd;
}*aa;
int e[10];
int ee[10][12];
enum data {Mondey, Friday, Sunday}data1;

int foo(int x,int y){
	int c;
	char a3;
	a3 = f8();
	c = g10();
	//aa->ddd->d1 = 0;	
	if(f1()&&x==f0()){
		y++;
		a2 = g8();
		a3 = g9();                
		x = g1();
 		f2();
		x = f7() + g7();
	}
	//while(x = g0()){}
	h1();
	a = f3();
	a = f4() + g4();
	a = f6();
        c = f5() + g5();
	return (x == g6());
}

void testme()
{
	int x;
	int y;	
	CAUT_INPUT(x);
	CAUT_INPUT(y);
	foo(x,y);
}
