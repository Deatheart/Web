#include "caut.h"


void test(int x){

	int i=0;
	int dg=0;

	while(i<x){

		if( x==1 ){
			dg++;
		}
		i++;
	}
}

void testme(){
	
	int x;

	CAUT_INPUT(x);

	test(x);
}
