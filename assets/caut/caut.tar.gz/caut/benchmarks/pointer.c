#include "caut.h"

int pointer(int** pp){

	if(pp==0)
		return 0;
	else{

		if(*pp == 5)
			return 1;
	}

}

/*
void testme(){

	int* p;
	CAUT_INPUT(p);
	pointer(p);

}
*/
